package com.focusterminale.app
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
class FocusAccessibilityService:AccessibilityService(){
 private var last=""
 override fun onAccessibilityEvent(e:AccessibilityEvent?){
  if(e?.eventType!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)return
  val p=e.packageName?.toString()?:return
  if(p==packageName||essential(p))return
  val s=SessionStore.current(this)?:run{last="";return}
  if(p!=last){last=p;performGlobalAction(GLOBAL_ACTION_HOME)
   runCatching{startActivity(Intent(this,BlockActivity::class.java).apply{addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP);putExtra("subject",s.subject);putExtra("end",s.end)})}
  }
 }
 private fun essential(p0:String):Boolean{val p=p0.lowercase();return p=="com.openai.chatgpt"||p.contains("dialer")||p.contains("incall")||p.contains("telecom")||p.contains("documentsui")||p.contains("filemanager")||p.contains("files")||p.contains("launcher")||p=="android"||p.contains("systemui")||p.contains("settings")||p.contains("permissioncontroller")}
 override fun onInterrupt(){}
}
