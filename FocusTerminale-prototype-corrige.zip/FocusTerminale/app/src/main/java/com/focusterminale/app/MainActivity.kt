package com.focusterminale.app
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
class MainActivity:Activity(){
 private val days=listOf("Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi")
 private lateinit var items:LinearLayout
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  val box=LinearLayout(this).apply{orientation=1;setPadding(24,24,24,24)}
  box.addView(TextView(this).apply{text="FOCUS TERMINALE";textSize=26f;gravity=Gravity.CENTER})
  box.addView(TextView(this).apply{text="Ajoute tes séances de travail";textSize=16f})
  val day=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,days)}
  val from=EditText(this).apply{hint="Début (HH:MM)"}
  val to=EditText(this).apply{hint="Fin (HH:MM)"}
  val subject=EditText(this).apply{hint="Matière / mission"}
  box.addView(day);box.addView(from);box.addView(to);box.addView(subject)
  box.addView(Button(this).apply{text="Ajouter la séance";setOnClickListener{
   val a=from.text.toString().trim();val b=to.text.toString().trim();val s=subject.text.toString().trim()
   if(!a.matches(Regex("\\d{2}:\\d{2}"))||!b.matches(Regex("\\d{2}:\\d{2}"))||a>=b||s.isBlank()) Toast.makeText(this@MainActivity,"Vérifie les heures et la matière.",0).show()
   else {val x=SessionStore.all(this@MainActivity).toMutableList();x.add(StudySession(day.selectedItemPosition+1,a,b,s));SessionStore.save(this@MainActivity,x);from.text.clear();to.text.clear();subject.text.clear();refresh();Toast.makeText(this@MainActivity,"Séance ajoutée",0).show()}
  }})
  box.addView(Button(this).apply{text="Activer le blocage dans Accessibilité";setOnClickListener{startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}})
  box.addView(TextView(this).apply{text="Active « Focus Terminale – blocage » dans les paramètres d’accessibilité.";textSize=13f})
  box.addView(TextView(this).apply{text="Mon planning";textSize=20f})
  items=LinearLayout(this).apply{orientation=1};box.addView(items)
  setContentView(ScrollView(this).apply{addView(box)});refresh()
 }
 private fun refresh(){items.removeAllViews();SessionStore.all(this).forEachIndexed{i,s->
  val row=LinearLayout(this).apply{orientation=0;gravity=Gravity.CENTER_VERTICAL}
  row.addView(TextView(this).apply{text="${days[s.day-1]}  ${s.start}–${s.end}  ${s.subject}";textSize=14f},LinearLayout.LayoutParams(0,-2,1f))
  row.addView(Button(this).apply{text="Supprimer";setOnClickListener{val x=SessionStore.all(this@MainActivity).toMutableList();x.removeAt(i);SessionStore.save(this@MainActivity,x);refresh()}})
  items.addView(row)
 };if(SessionStore.all(this).isEmpty())items.addView(TextView(this).apply{text="Aucune séance enregistrée."})}
}
