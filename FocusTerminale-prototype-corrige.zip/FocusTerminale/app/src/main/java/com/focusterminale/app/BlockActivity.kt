package com.focusterminale.app
import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.*
class BlockActivity:Activity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);val subject=intent.getStringExtra("subject")?:"Ta matière";val end=intent.getStringExtra("end")?:""
  val v=LinearLayout(this).apply{orientation=1;gravity=Gravity.CENTER;setPadding(28,28,28,28)}
  v.addView(TextView(this).apply{text="C’EST L’HEURE DE TRAVAIL";textSize=22f;gravity=Gravity.CENTER})
  v.addView(TextView(this).apply{text=subject;textSize=32f;gravity=Gravity.CENTER;setPadding(0,24,0,12)})
  v.addView(TextView(this).apply{text="Ta séance se termine à $end.";textSize=16f;gravity=Gravity.CENTER})
  v.addView(TextView(this).apply{text="Les applications distrayantes sont bloquées pendant ce créneau. ChatGPT, les appels et les fichiers restent accessibles.";gravity=Gravity.CENTER;setPadding(0,24,0,24)})
  v.addView(Button(this).apply{text="Retour à l’accueil";setOnClickListener{finish();moveTaskToBack(true)}});setContentView(v)
 }
 override fun onBackPressed(){}
}
