package com.focusterminale.app
import android.content.Context
import java.util.Calendar
data class StudySession(val day:Int,val start:String,val end:String,val subject:String)
object SessionStore {
 private const val PREF="focus_terminal_prefs"; private const val KEY="sessions"
 fun all(c:Context):List<StudySession> = (c.getSharedPreferences(PREF,0).getString(KEY,"")?: "").lines().mapNotNull {
  val p=it.split("|"); if(p.size==4) runCatching { StudySession(p[0].toInt(),p[1],p[2],p[3]) }.getOrNull() else null
 }
 fun save(c:Context,x:List<StudySession>) { c.getSharedPreferences(PREF,0).edit().putString(KEY,x.joinToString("\n"){"${it.day}|${it.start}|${it.end}|${it.subject.replace("|"," ")}"}).apply() }
 fun current(c:Context):StudySession? { val n=Calendar.getInstance(); val d=n.get(Calendar.DAY_OF_WEEK); val t="%02d:%02d".format(n.get(Calendar.HOUR_OF_DAY),n.get(Calendar.MINUTE)); return all(c).firstOrNull{it.day==d && t>=it.start && t<it.end} }
}
