# Focus Terminale – prototype Android

Prototype natif Kotlin pour Android 8+ (cible Android 12).

## Inclus
- Création et suppression de séances hebdomadaires.
- Affichage d'un écran indiquant la matière pendant les créneaux.
- Tentative de blocage des applications non autorisées via le service d'accessibilité.
- Exceptions intégrées pour ChatGPT, téléphone/appels, gestionnaire de fichiers et fonctions système.

## Limites à connaître
Ce prototype n'est pas un verrouillage inviolable. L'utilisateur peut désactiver le service dans Accessibilité. Selon la version de HiOS/Android, le lancement de l'écran de blocage peut être limité. Les noms des applications Téléphone et Fichiers varient selon les TECNO : il faudra tester les exceptions sur l'appareil.
Les appels d'urgence et les fonctions système essentiels ne doivent pas être bloqués. Le code est une première base à tester, pas encore une version prête à commercialiser.

## Construire l'APK
1. Ouvrir le dossier dans Android Studio sur un ordinateur.
2. Synchroniser Gradle.
3. Choisir Build > Build APK(s).
4. Installer l'APK sur le téléphone.
5. Ouvrir Focus Terminale puis activer « Focus Terminale – blocage » dans Paramètres > Accessibilité.

Les jours sont récurrents chaque semaine. Les heures doivent être au format 24 h, par exemple 12:40.
