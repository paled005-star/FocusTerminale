package com.focusterminale.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.widget.EditText
import android.widget.Toast
import java.util.Calendar

const val MAX_EMERGENCY_PER_WEEK = 2
const val EMERGENCY_MINUTES = 15

object Store {
    private fun p(c: Context) = c.getSharedPreferences("focus", Context.MODE_PRIVATE)

    fun installTime(c: Context): Long {
        val v = p(c).getLong("install", 0L)
        if (v != 0L) return v
        val now = System.currentTimeMillis()
        p(c).edit().putLong("install", now).apply()
        return now
    }

    private fun set(c: Context, k: String) = HashSet(p(c).getStringSet(k, emptySet()) ?: emptySet())

    fun isDone(c: Context, key: String) = key in set(c, "done")
    fun setDone(c: Context, key: String, done: Boolean) {
        val s = set(c, "done"); if (done) s.add(key) else s.remove(key)
        p(c).edit().putStringSet("done", s).apply()
    }

    fun note(c: Context, key: String): String = p(c).getString("note|$key", "") ?: ""
    fun setNote(c: Context, key: String, text: String) {
        p(c).edit().putString("note|$key", text.trim()).apply()
    }

    fun emergencyActive(c: Context) = System.currentTimeMillis() < p(c).getLong("unlock_until", 0L)

    fun emergenciesThisWeek(c: Context): Int {
        val since = Schedule.mondayOf(Calendar.getInstance()).timeInMillis
        return set(c, "emerg").count { (it.toLongOrNull() ?: 0L) >= since }
    }

    fun startEmergency(c: Context) {
        val now = System.currentTimeMillis()
        val s = set(c, "emerg"); s.add(now.toString())
        p(c).edit().putStringSet("emerg", s).putLong("unlock_until", now + EMERGENCY_MINUTES * 60_000L).apply()
    }
}

fun Activity.showEmergencyDialog(onUnlocked: () -> Unit) {
    val used = Store.emergenciesThisWeek(this)
    if (used >= MAX_EMERGENCY_PER_WEEK) {
        Toast.makeText(this, "Plus de déblocage d’urgence cette semaine.", Toast.LENGTH_LONG).show()
        return
    }
    val input = EditText(this).apply { hint = "URGENCE" }
    AlertDialog.Builder(this)
        .setTitle("Déblocage d’urgence")
        .setMessage("Débloque tout pendant $EMERGENCY_MINUTES min (${MAX_EMERGENCY_PER_WEEK - used} restant(s) cette semaine). Tape URGENCE pour confirmer.")
        .setView(input)
        .setNegativeButton("Annuler", null)
        .setPositiveButton("Débloquer") { _, _ ->
            if (input.text.toString().trim().uppercase() == "URGENCE") {
                Store.startEmergency(this)
                Toast.makeText(this, "Débloqué pour $EMERGENCY_MINUTES minutes.", Toast.LENGTH_LONG).show()
                onUnlocked()
            } else Toast.makeText(this, "Mot incorrect.", Toast.LENGTH_SHORT).show()
        }.show()
}
