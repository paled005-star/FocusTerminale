package com.focusterminale.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

class FocusAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var currentPkg = ""
    private var lastBlock = 0L

    // Vérifie régulièrement l'app ouverte : le blocage démarre à l'heure pile,
    // même si une app distrayante était déjà ouverte.
    private val ticker = object : Runnable {
        override fun run() { check(); handler.postDelayed(this, 3000) }
    }

    override fun onServiceConnected() { handler.post(ticker) }

    override fun onDestroy() { handler.removeCallbacks(ticker); super.onDestroy() }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        val p = pkg.lowercase()
        if (p.contains("inputmethod") || p.contains("keyboard")) return // le clavier ne change pas l'app active
        currentPkg = pkg
        check()
    }

    private fun check() {
        val pkg = currentPkg
        if (pkg.isEmpty() || pkg == packageName || Schedule.isAllowed(pkg)) return
        if (Store.emergencyActive(this)) return
        if (Schedule.currentOcc() == null) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastBlock < 1500) return
        lastBlock = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        runCatching {
            startActivity(Intent(this, BlockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            })
        }
    }

    override fun onInterrupt() {}
}
