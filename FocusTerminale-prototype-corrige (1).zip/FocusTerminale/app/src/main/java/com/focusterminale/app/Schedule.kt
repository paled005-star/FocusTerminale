package com.focusterminale.app

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Un créneau. day: 0 = Lundi ... 6 = Dimanche. Une fin > 24:00 déborde sur le lendemain (ex. 25:00 = 01:00). */
class Slot(val day: Int, val from: String, val to: String, val subject: String) {
    val endLabel: String get() = "%02d:%02d".format((minutes(to) / 60) % 24, minutes(to) % 60)
}

/** Une occurrence datée d'un créneau (une semaine précise). */
class Occ(val slot: Slot, val start: Calendar, val end: Calendar) {
    val key: String get() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(start.time) + "|" + slot.day + "|" + slot.from
}

private fun minutes(t: String): Int = t.split(":").let { it[0].toInt() * 60 + it[1].toInt() }

object Schedule {
    val DAYS = listOf("Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche")

    // ===== TON EMPLOI DU TEMPS : modifie ici si besoin =====
    val slots: List<Slot> = listOf(
        // Lundi
        Slot(0, "10:00", "10:10", "SVT : rappel rapide"),
        Slot(0, "12:40", "14:00", "SVT : exercices"),
        Slot(0, "18:00", "22:00", "SVT : exercices et corrections"),
        Slot(0, "22:00", "25:00", "PC : préparation du lendemain"),
        // Mardi
        Slot(1, "10:00", "10:10", "SVT : rappel rapide"),
        Slot(1, "12:40", "14:00", "SVT : exercices"),
        Slot(1, "22:00", "24:00", "SVT : approfondissement"),
        Slot(1, "24:00", "26:00", "Maths : préparation du lendemain"),
        // Mercredi
        Slot(2, "10:00", "10:10", "Maths : rappel rapide"),
        Slot(2, "12:40", "14:00", "Maths : exercices"),
        Slot(2, "22:00", "24:00", "Maths : approfondissement"),
        Slot(2, "24:00", "26:00", "Français : préparation du lendemain"),
        // Jeudi
        Slot(3, "10:00", "10:10", "Maths : rappel rapide"),
        Slot(3, "12:40", "14:00", "Maths : exercices"),
        Slot(3, "18:00", "22:00", "Maths : exercices et corrections"),
        Slot(3, "22:00", "25:00", "Histoire-Géographie"),
        // Vendredi
        Slot(4, "10:00", "10:10", "PC : rappel rapide"),
        Slot(4, "12:40", "14:00", "PC : exercices"),
        Slot(4, "18:00", "22:00", "PC : exercices et corrections"),
        Slot(4, "22:00", "25:00", "SVT"),
        // Samedi
        Slot(5, "07:00", "15:00", "Anglais, Philosophie et Français"),
        Slot(5, "15:00", "25:00", "Rattrapage des matières en retard"),
        // Dimanche
        Slot(6, "13:00", "14:00", "SVT : préparation du lundi"),
        Slot(6, "18:00", "22:00", "Maths"),
        Slot(6, "22:00", "25:00", "SVT"),
    )

    // ===== APPS TOUJOURS AUTORISÉES =====
    private val allowedExact = setOf(
        "com.openai.chatgpt",   // ChatGPT
        "android",
    )
    private val allowedContains = listOf(
        // Téléphone / appels
        "dialer", "incallui", "telecom", "telephony",
        // Fichiers
        "documentsui", "filemanager",
        // Calculatrice, horloge
        "calculator", "deskclock",
        // Système : écran d'accueil, barre d'état, clavier, permissions
        "launcher", "systemui", "inputmethod", "keyboard", "permissioncontroller",
    )

    fun isAllowed(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p in allowedExact || allowedContains.any { p.contains(it) }
    }

    fun mondayOf(now: Calendar): Calendar {
        val c = now.clone() as Calendar
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.DAY_OF_MONTH, -((c.get(Calendar.DAY_OF_WEEK) + 5) % 7))
        return c
    }

    private fun at(monday: Calendar, day: Int, t: String): Calendar {
        val c = monday.clone() as Calendar
        c.add(Calendar.DAY_OF_MONTH, day)
        c.set(Calendar.HOUR_OF_DAY, minutes(t) / 60)
        c.set(Calendar.MINUTE, minutes(t) % 60)
        c.timeInMillis // normalise (24:00, 25:00 passent au lendemain)
        return c
    }

    fun occurrences(monday: Calendar): List<Occ> =
        slots.map { Occ(it, at(monday, it.day, it.from), at(monday, it.day, it.to)) }

    fun currentOcc(now: Calendar = Calendar.getInstance()): Occ? {
        val m = mondayOf(now)
        val prev = (m.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, -7) }
        return (occurrences(prev) + occurrences(m)).firstOrNull { !now.before(it.start) && now.before(it.end) }
    }
}
