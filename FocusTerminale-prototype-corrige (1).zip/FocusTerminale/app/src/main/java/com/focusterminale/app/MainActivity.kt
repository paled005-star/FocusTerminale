package com.focusterminale.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var week: LinearLayout
    private val dayFmt = SimpleDateFormat("EEE dd/MM", Locale.FRANCE)
    private val dateFmt = SimpleDateFormat("dd/MM", Locale.FRANCE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.installTime(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        box.addView(TextView(this).apply { text = "FOCUS TERMINALE"; textSize = 26f; gravity = Gravity.CENTER })
        status = TextView(this).apply { textSize = 18f; setPadding(0, 24, 0, 16) }
        box.addView(status)
        box.addView(Button(this).apply {
            text = "Activer le blocage (Accessibilité)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        box.addView(Button(this).apply {
            text = "Déblocage d’urgence"
            setOnClickListener { showEmergencyDialog { refresh() } }
        })
        box.addView(TextView(this).apply { text = "Ma discipline"; textSize = 20f; setPadding(0, 24, 0, 8) })
        stats = TextView(this).apply { textSize = 14f }
        box.addView(stats)
        box.addView(TextView(this).apply { text = "Cette semaine"; textSize = 20f; setPadding(0, 24, 0, 8) })
        week = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(week)
        setContentView(ScrollView(this).apply { addView(box) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val now = Calendar.getInstance()
        val cur = Schedule.currentOcc(now)
        val unlock = if (Store.emergencyActive(this)) "\nDéblocage d’urgence actif." else ""
        status.text = (if (cur == null) "Aucune séance en ce moment." else "Séance en cours : ${cur.slot.subject} (jusqu’à ${cur.slot.endLabel})") + unlock

        week.removeAllViews()
        val install = Store.installTime(this)
        Schedule.occurrences(Schedule.mondayOf(now)).sortedBy { it.start.timeInMillis }.forEach { occ ->
            val done = Store.isDone(this, occ.key)
            val started = !now.before(occ.start)
            val over = !now.before(occ.end)
            val state = when {
                done -> "✔ Faite"
                over && occ.start.timeInMillis >= install -> "✘ Manquée"
                over -> "—"
                started -> "En cours"
                else -> "À venir"
            }
            val note = Store.note(this, occ.key)
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 12) }
            card.addView(TextView(this).apply {
                text = "${dayFmt.format(occ.start.time)} ${occ.slot.from.removePrefix("0")}–${occ.slot.endLabel}  ·  $state\n${occ.slot.subject}" +
                    if (note.isNotBlank()) "\nÀ réviser : $note" else ""
                textSize = 14f
            })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(Button(this).apply { text = "À réviser"; setOnClickListener { editNote(occ) } })
            if (started) row.addView(Button(this).apply {
                text = if (done) "Annuler" else "Fait"
                setOnClickListener { Store.setDone(this@MainActivity, occ.key, !done); refresh() }
            })
            card.addView(row)
            week.addView(card)
        }
        stats.text = computeStats(now, install)
    }

    private fun editNote(occ: Occ) {
        val input = EditText(this).apply { setText(Store.note(this@MainActivity, occ.key)); hint = "Ex. chapitre 3, exos 12 à 18" }
        AlertDialog.Builder(this)
            .setTitle(occ.slot.subject)
            .setMessage("Que dois-tu réviser pendant cette séance ?")
            .setView(input)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer") { _, _ -> Store.setNote(this, occ.key, input.text.toString()); refresh() }
            .show()
    }

    private fun computeStats(now: Calendar, install: Long): String {
        var planned = 0; var done = 0
        val lines = mutableListOf<String>()
        var monday = Schedule.mondayOf(now)
        for (i in 0 until 52) {
            val finished = Schedule.occurrences(monday).filter {
                it.start.timeInMillis >= install && !now.before(it.end)
            }
            val d = finished.count { Store.isDone(this, it.key) }
            planned += finished.size; done += d
            if (i < 4 && finished.isNotEmpty())
                lines.add("Semaine du ${dateFmt.format(monday.time)} : $d/${finished.size} (${d * 100 / finished.size} %)")
            monday = (monday.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, -7) }
            if (monday.timeInMillis + 7 * 86_400_000L < install) break
        }
        if (planned == 0) return "Pas encore de séance terminée.\nUrgences cette semaine : ${Store.emergenciesThisWeek(this)}/$MAX_EMERGENCY_PER_WEEK"
        return "Séances faites : $done   Manquées : ${planned - done}\nRespect du programme : ${done * 100 / planned} %\n" +
            lines.joinToString("\n") + "\nUrgences cette semaine : ${Store.emergenciesThisWeek(this)}/$MAX_EMERGENCY_PER_WEEK"
    }
}
