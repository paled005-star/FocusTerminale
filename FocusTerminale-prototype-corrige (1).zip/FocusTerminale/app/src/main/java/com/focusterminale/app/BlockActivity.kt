package com.focusterminale.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BlockActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val occ = Schedule.currentOcc()
        if (occ == null) { finish(); return }
        val note = Store.note(this, occ.key)
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(28, 28, 28, 28) }
        fun text(t: String, size: Float, top: Int = 0) = v.addView(TextView(this).apply {
            text = t; textSize = size; gravity = Gravity.CENTER; setPadding(0, top, 0, 0)
        })
        text("C’EST L’HEURE DE TRAVAIL", 22f)
        text(occ.slot.subject, 30f, 24)
        if (note.isNotBlank()) text("À réviser : $note", 18f, 16)
        text("Ta séance se termine à ${occ.slot.endLabel}.", 16f, 16)
        text("Les applications distrayantes sont bloquées. ChatGPT, les appels et les fichiers restent accessibles.", 14f, 24)
        v.addView(Button(this).apply { text = "Retour à l’accueil"; setOnClickListener { finish(); moveTaskToBack(true) } })
        v.addView(Button(this).apply { text = "Déblocage d’urgence"; setOnClickListener { showEmergencyDialog { finish() } } })
        setContentView(v)
    }

    @Deprecated("Retour désactivé pendant le blocage")
    override fun onBackPressed() {}
}
