# Focus Terminale – app personnelle Android

Emploi du temps d'étude intégré dans `Schedule.kt` (modifiable), apps autorisées dans le même fichier.

## Fonctions
- Blocage de toutes les apps non autorisées pendant les créneaux (réseaux sociaux, jeux, etc.).
- Apps toujours accessibles : ChatGPT, téléphone, fichiers, calculatrice, horloge, système.
- Par séance : champ « À réviser », affiché sur l'écran de blocage.
- Suivi : séances faites (bouton « Fait ») / manquées, taux par semaine.
- Déblocage d'urgence : 15 min, 2 fois max par semaine, mot de confirmation « URGENCE ».

## Limites à connaître
Ce prototype n'est pas un verrouillage inviolable. L'utilisateur peut désactiver le service dans Accessibilité. Selon la version de HiOS/Android, le lancement de l'écran de blocage peut être limité. Les noms des applications Téléphone et Fichiers varient selon les TECNO : il faudra tester les exceptions sur l'appareil.
Les appels d'urgence et les fonctions système essentiels ne doivent pas être bloqués. Le code est une première base à tester, pas encore une version prête à commercialiser.

## Construire l'APK
1. Ouvrir le dossier dans Android Studio sur un ordinateur.
2. Synchroniser Gradle.
3. Choisir Build > Build APK(s).
4. Installer l'APK sur le téléphone.
5. Ouvrir Focus Terminale puis activer « Focus Terminale – blocage » dans Paramètres > Accessibilité.

Les jours sont récurrents chaque semaine. Les heures doivent être au format 24 h, par exemple 12:40.
